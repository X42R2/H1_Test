# Brainstorm & research 
- [WireShark](https://www.wireshark.org/)
  - Protocol analyzer
- [MagicPlan](https://cloud.magicplan.app)
  - https://cloud.magicplan.app/plan/5ee872561b563#/